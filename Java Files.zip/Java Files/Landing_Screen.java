package com.example.otamsapplication;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

public class Landing_Screen extends AppCompatActivity {
    public static final String newLand = "NEW USER";
    public static final String newAdmin = "NEW ADMIN";


    private void login(String adminLogin) {
        Intent newAdm = new Intent(this, MainActivity.class);
        newAdm.putExtra(newAdmin, adminLogin);
        newAdm.putExtra(newLand, adminLogin);
        startActivity(newAdm);
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_landing_screen);

        View newStudent = findViewById(R.id.linkRegisterStudent);
        if(newStudent != null) {
            newStudent.setOnClickListener(v -> startActivity(new Intent(this, Student_Side.class)));
        }

        View admin = findViewById(R.id.linkDevAdmin);
        if(admin != null) {
            admin.setOnClickListener(v -> login("Administrator"));
        }

        View tutor = findViewById(R.id.btnRegisterTutor);
        if(tutor != null) {
            tutor.setOnClickListener(v -> startActivity(new Intent(this, Tutor_Side.class)));
        }

        View student = findViewById(R.id.linkRegisterStudent);
        if(student != null) {
            student.setOnClickListener(v -> startActivity(new Intent(this, Student_Side.class)));
        }
        Button signIn = findViewById(R.id.btnSignin);
        EditText emailAdd = findViewById(R.id.email);
        EditText userPassword = findViewById(R.id.password);

        signIn.setOnClickListener(v -> {
            String emailAddress = emailAdd.getText().toString().trim();
            String password = userPassword.getText().toString();

            final String adEm = "admin@otams.com";
            final String adPa = "Admin@$345";

            if (emailAddress.equals(adEm) && password.equals(adPa)) {
                Intent log = new Intent(this, MainActivity.class);
                log.putExtra(newLand, "Administrator");
                startActivity(log);
            } else {
                Toast.makeText(this, "Invalid Credentials", Toast.LENGTH_SHORT).show();
            }
        });
    }
}